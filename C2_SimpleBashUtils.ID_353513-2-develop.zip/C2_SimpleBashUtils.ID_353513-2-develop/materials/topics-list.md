Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project. 

We will learn: 
- working with command line arguments;
- code decomposition;
- working with regular expressions
- working with files;
- working with dynamic memory, and proper error handling.

Now that you know what to expect in this project, you can slowly begin to study the topics listed above. 😇
